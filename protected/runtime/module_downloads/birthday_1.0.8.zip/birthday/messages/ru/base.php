<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Дни рождения</strong>в ближайшие {days} дни',
  'Back to modules' => 'Назад к модулям',
  'Birthday Module Configuration' => 'Настройки модуля День рождения',
  'In {days} days' => 'Через {days} дней',
  'Save' => 'Сохранить',
  'The number of days future bithdays will be shown within.' => 'Количество отображаемых в блоке дней рождения.',
  'Tomorrow' => 'Завтра',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Вы можете настроить количество предстоящих дней рождения для отображения в блоке.',
  'becomes {years} years old.' => 'будет {years} лет.',
  'today' => 'сегодня',
);
