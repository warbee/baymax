<?php
return array (
  'Answers' => 'Antwoorden',
  'Multiple answers per user' => 'Meerdere antwoorden per gebruiker',
  'Please specify at least {min} answers!' => 'Gelieve minstens {min} antwoorden te geven!',
  'Question' => 'Vraag',
);
