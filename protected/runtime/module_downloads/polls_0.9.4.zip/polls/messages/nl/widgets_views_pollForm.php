<?php
return array (
  'Add answer...' => 'Antwoord toevoegen...',
  'Allow multiple answers per user?' => 'Meerdere antwoorden per gebruiker toelaten?',
  'Anonymous Votes?' => 'Anoniem stemmen?',
  'Ask something...' => 'Stel je vraag...',
  'Display answers in random order?' => 'Antwoorden in willekeurige volgorde weergeven?',
  'Edit answer (empty answers will be removed)...' => 'Antwoorden veranderen (Lege antwoorden worden verwijderd)',
  'Edit your poll question...' => 'Verander de vraag...',
);
