<?php
return array (
  'Anonymous' => 'Anoniem',
  'Closed' => 'Gesloten',
  'Reset my vote' => 'Reset mijn antwoord',
  'Vote' => 'Stem',
  'and {count} more vote for this.' => 'en {count} anderen hebben voor dit gestemd.',
  'votes' => 'stemmen',
);
