<?php
return array (
  '{userName} created a new {question}.' => '{userName} создал новый {question}.',
);
