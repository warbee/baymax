<?php
return array (
  'User who vote this' => 'Utilisateurs qui vont répondre à ça',
);
