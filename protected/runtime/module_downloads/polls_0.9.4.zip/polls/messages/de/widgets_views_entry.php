<?php
return array (
  'Anonymous' => 'Anonym',
  'Closed' => 'Beendet',
  'Reset my vote' => 'Meine Abstimmung zurücksetzen',
  'Vote' => 'Abstimmen',
  'and {count} more vote for this.' => 'und {count} mehr stimmten hierfür ab.',
  'votes' => 'Abstimmungen',
);
