<?php
return array (
  'Allows to start polls.' => 'Ermöglicht Umfragen zu starten.',
  'Polls' => 'Umfragen',
);
