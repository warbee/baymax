<?php
return array (
  'Anonymous' => 'ناشناس',
  'Closed' => 'بسته',
  'Reset my vote' => 'رای من را مجددا تنظیم‌کن',
  'Vote' => 'رای دادن',
  'and {count} more vote for this.' => 'و {count} نفر دیگر به این رای دادند.',
  'votes' => 'آرا',
);
