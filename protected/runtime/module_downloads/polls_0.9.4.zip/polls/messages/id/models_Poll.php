<?php
return array (
  'Answers' => 'Jawaban',
  'Multiple answers per user' => 'Beberapa jawaban per pengguna',
  'Please specify at least {min} answers!' => 'Silahkan tentukan setidaknya {min} jawaban!',
  'Question' => 'Pertanyaan',
);
