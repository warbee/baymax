<?php
return array (
  'Anonymous' => 'Misafir',
  'Closed' => 'Kapalı',
  'Reset my vote' => 'Oyumu sıfırla',
  'Vote' => 'Oyla',
  'and {count} more vote for this.' => 've {count} oy verildi.',
  'votes' => 'oylar',
);
