<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Henüz anket oluşturulmamış!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Henüz anket oluşturulmamış!</b><br>İlk anketi oluştur...',
  'Asked by me' => 'Bana sorulan',
  'No answered yet' => 'Henüz cevap yok',
  'Only private polls' => 'Sadece özel anketler',
  'Only public polls' => 'Sadece genel anketler',
);
