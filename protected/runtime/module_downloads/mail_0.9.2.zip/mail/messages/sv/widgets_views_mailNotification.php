<?php
return array (
  'Messages' => 'Meddelanden',
  'New message' => '',
  'Show all messages' => '',
);
