<?php
return array (
  '<strong>New</strong> message' => '<strong>Nytt</strong> medelande',
  'Reply now' => 'Svara nu',
  'sent you a new message:' => 'skickade dig ett nytt meddelande:',
);
