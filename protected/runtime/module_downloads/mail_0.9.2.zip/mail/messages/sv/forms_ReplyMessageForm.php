<?php
return array (
  'Message' => 'Medelande',
);
