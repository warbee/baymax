<?php
return array (
  'sent you a new message in' => 'sendte dig en ny besked i',
);
