<?php
return array (
  '<strong>New</strong> message' => '<strong>Ny</strong> besked',
  'Reply now' => 'Svar nu',
  'sent you a new message:' => 'sendte dig en ny besked:',
);
