<?php
return array (
  'Recipient' => 'گيرنده',
  'You cannot send a email to yourself!' => 'شما نمي توانيد به خودتان پيام بفرستيد',
);
