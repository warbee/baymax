<?php
return array (
  'Message' => 'پیغام',
  'Recipient' => 'گیرنده',
  'Subject' => 'موضوع',
  'You cannot send a email to yourself!' => 'شما نمي توانيد پيامي براي خودتان ارسال كنيد',
);
