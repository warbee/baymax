<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Potwierdź</strong> usunięcie rozmowy',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Potwierdź</strong>  opuszczenie rozmowy',
  '<strong>Confirm</strong> message deletion' => '<strong>Potwierdź</strong> usunięcie wiadomości',
  'Add user' => 'Dodaj użytkownika ',
  'Cancel' => 'Anuluj',
  'Delete' => 'Usuń',
  'Delete conversation' => 'Usuń rozmowę',
  'Do you really want to delete this conversation?' => 'Na pewno chcesz usunąć rozmowę?',
  'Do you really want to delete this message?' => 'Na pewno chcesz usunąć wiadomość?',
  'Do you really want to leave this conversation?' => 'Na pewno chcesz opuścić rozmowę?',
  'Leave' => 'Opuść',
  'Leave conversation' => 'Opuść rozmowę',
  'Leave discussion' => 'Opuść dyskusję ',
  'Send' => 'Wyślij ',
  'There are no messages yet.' => 'Nie ma jeszcze wiadomości. ',
  'Write an answer...' => 'Napisz odpowiedź... ',
);
