<?php
return array (
  'Add recipients' => 'Dodaj odbiorców',
  'Close' => 'Zamknij ',
  'New message' => 'Nowa wiadomość ',
  'Send' => 'Wyślij ',
);
