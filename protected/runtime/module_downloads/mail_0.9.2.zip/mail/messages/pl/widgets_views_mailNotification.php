<?php
return array (
  'Messages' => 'Wiadomości ',
  'New message' => 'Nowa wiadomość ',
  'Show all messages' => 'Pokaż wszystkie wiadomości ',
);
