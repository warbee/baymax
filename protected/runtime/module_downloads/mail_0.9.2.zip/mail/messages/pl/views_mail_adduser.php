<?php
return array (
  'Add more participants to your conversation...' => 'Dodaj więcej odbiorców do twojej konwersacji ',
  'Close' => 'Zamknij ',
  'Send' => 'Wyślij ',
);
