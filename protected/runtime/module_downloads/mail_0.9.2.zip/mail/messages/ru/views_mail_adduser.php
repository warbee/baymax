<?php
return array (
  'Add more participants to your conversation...' => 'Добавить участников в переписку...',
  'Close' => 'Закрыть',
  'Send' => 'Отправить',
);
