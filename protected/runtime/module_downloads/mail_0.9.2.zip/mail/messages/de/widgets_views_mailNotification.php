<?php
return array (
  'Messages' => 'Nachrichten',
  'New message' => 'Neue Nachricht',
  'Show all messages' => 'Zeige alle Nachrichten',
);
