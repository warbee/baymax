<?php
return array (
  'Add more participants to your conversation...' => 'Añadir mas participantes a tu conversación...',
  'Close' => 'Cerrrar',
  'Send' => 'Enviar',
);
