<?php
return array (
  'Edit message entry' => 'Editar mensaje',
  'Save' => 'Guardar',
);
