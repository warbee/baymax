<?php
return array (
  'Add more participants to your conversation...' => 'Afegeix més participants a la conversa...',
  'Close' => 'Tanca',
  'Send' => 'Envia',
);
