<?php
return array (
  'New message' => 'رسالة جديدة',
  'Send message' => 'ارسال رسالة',
);
