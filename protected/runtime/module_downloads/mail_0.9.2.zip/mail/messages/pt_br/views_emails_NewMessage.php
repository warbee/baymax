<?php
return array (
  '<strong>New</strong> message' => '<strong>Nova</strong> mensagem',
  'Reply now' => 'Responder agora',
  'sent you a new message:' => 'enviar uma nova mensagem:',
);
